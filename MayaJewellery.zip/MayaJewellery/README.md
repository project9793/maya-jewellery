# Maya Jewellery (Kotlin + XML)
GitHub पर push करें → Actions टैब → "Build APK" → Artifacts से MayaJewellery-APK डाउनलोड करें।
