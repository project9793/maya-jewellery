# माया ज्वेलरी (Maya Jewellery)

सोना खरीदने से पहले सही भाव और सही बिल जानने वाला Android ऐप।
Kotlin + XML (native Android, ViewBinding, Material Components), पूरी तरह ऑफलाइन।

## क्या-क्या है ऐप में

1. **भाव (Rates)** — 24 कैरेट 999 का भाव प्रति 10 ग्राम डालें। ऐप अपने आप हर कैरेट का भाव निकाल देता है:
   24K 999, 23K 958, 22K 916, 20K 833, 18K 750, 14K 585, 9K 375।
   भाव का इतिहास भी सेव रहता है, ऊपर-नीचे के फर्क के साथ।
   फॉर्मूला: `भाव प्रति ग्राम = (999 का भाव ÷ 999) × फाइननेस`
   जैसे 150000 ÷ 999 × 750 = ₹11261 प्रति ग्राम (18 कैरेट)।

2. **खरीद (Buy calculator)** — वजन, कैरेट, मेकिंग चार्ज (प्रतिशत या रुपये प्रति ग्राम), वेस्टेज, नग-डायमंड और
   हॉलमार्किंग चार्ज डालें। पूरा बिल टूटकर दिखता है: सोना, मेकिंग, वेस्टेज, नग, हॉलमार्किंग, GST, कुल देय,
   असली दाम प्रति ग्राम, और सोने के भाव से कितना ज्यादा लिया जा रहा है। बिल शेयर भी कर सकते हैं।
   GST: 3% पूरे बिल पर (डिफ़ॉल्ट), या स्विच ऑन करने पर 3% धातु पर + 5% मेकिंग पर।

3. **बिक्री (Sell / exchange)** — जौहरी जो दाम दे रहा है उसकी तुलना उचित दाम से करें,
   कटौती प्रतिशत डालकर। कम दाम पर साफ चेतावनी।

4. **सावधानी (Guide)** — हॉलमार्क के तीन निशान और HUID, कैरेट-फाइननेस टेबल, मेकिंग चार्ज, वेस्टेज,
   GST, बिल चेकलिस्ट, वापस बेचने के नियम, स्कीम और ऑफर की सच्चाई।

भाषा: फोन हिंदी में हो तो हिंदी, अंग्रेजी में हो तो अंग्रेजी (res/values और res/values-en)।

## कैसे बनाएं (APK)

1. Android Studio (Ladybug या नया) खोलें → **Open** → यह `MayaJewellery` फोल्डर चुनें।
2. पहली बार Gradle 8.7 और लाइब्रेरी खुद डाउनलोड होंगी (इंटरनेट चाहिए, एक बार)।
3. **Build → Build Bundle(s) / APK(s) → Build APK(s)**।
4. APK यहां मिलेगी: `app/build/outputs/apk/debug/app-debug.apk`

कमांड लाइन से: `./gradlew assembleDebug`
(अगर `gradlew` फाइल न हो तो Android Studio सिंक करते ही बना देता है, या `gradle wrapper` चलाएं।)

### जरूरी सेटिंग
- compileSdk 34, minSdk 24, targetSdk 34, Java 17, Kotlin 1.9.24, AGP 8.5.2
- कोई इंटरनेट परमिशन नहीं — ऐप पूरी तरह ऑफलाइन चलता है

## फोल्डर

```
app/src/main/java/com/mayajewellery/app/
  MainActivity.kt            बॉटम नेविगेशन, टैब बदलना
  data/Carat.kt              सभी कैरेट और भाव का फॉर्मूला
  data/RateRepository.kt     भाव + इतिहास (SharedPreferences)
  ui/RatesFragment.kt        भाव स्क्रीन
  ui/CalculatorFragment.kt   खरीद का हिसाब
  ui/SellFragment.kt         बिक्री का हिसाब
  ui/GuideFragment.kt        सावधानी स्क्रीन
  ui/CaratAdapter.kt, ui/HistoryAdapter.kt
  util/Money.kt              भारतीय फॉर्मेट में रकम
app/src/main/res/layout/     सारे XML लेआउट
app/src/main/res/values/     हिंदी स्ट्रिंग्स
app/src/main/res/values-en/  अंग्रेजी स्ट्रिंग्स
```

## GitHub से APK बनाना (Actions)

`.github/workflows/release.yml` पहले से जुड़ा है। रेपो में सोर्स जाने के बाद:

1. GitHub पर **Actions** टैब खोलें → **Release APK** → **Run workflow** (या `main` पर पुश होते ही खुद चलेगा)
2. हरा टिक आने पर उसी रन के नीचे **Artifacts → maya-jewellery-apk** डाउनलोड करें — वही फोन पर इंस्टॉल होने वाली APK है
3. टैग डालने पर (`git tag v1.0 && git push origin v1.0`) APK सीधे **Releases** में भी जुड़ जाती है

वर्कफ़्लो दो हालत में चलता है — सोर्स सीधे रेपो में हो, या सिर्फ `MayaJewellery.zip` रेपो में रखी हो (तब वो ज़िप खोलकर बिल्ड करता है)।

अगर अपनी चाबी से साइन करना हो तो रेपो में ये Secrets जोड़ें:
`MAYA_STORE_FILE` (कोई भी टेक्स्ट), `MAYA_KEYSTORE_BASE64`, `MAYA_STORE_PASSWORD`, `MAYA_KEY_ALIAS`, `MAYA_KEY_PASSWORD`।
इनके बिना APK डिबग की से साइन होती है, जो फोन पर चल जाती है।

## ध्यान रखें
ऐप में भाव आप खुद डालते हैं। ऐप किसी दुकान का भाव नहीं देता और न ही लाइव रेट API से जुड़ा है,
इसलिए रोज सुबह अपने शहर का 24K भाव एक बार डाल लें।
