plugins {
    id("com.android.application")
    id("org.jetbrains.kotlin.android")
}

android {
    namespace = "com.mayajewellery.app"
    compileSdk = 34

    defaultConfig {
        applicationId = "com.mayajewellery.app"
        minSdk = 24
        targetSdk = 34
        versionCode = 1
        versionName = "1.0"
    }

    // रिलीज़ की चाबी (keystore) गिट में नहीं रखी जाती। बिना प्रॉपर्टी के रिलीज़ APK
    // डिबग की से ज़ाइन होता है, जो फोन पर इंस्टॉल हो जाता है।
    //   ./gradlew assembleRelease -PMAYA_STORE_FILE=../maya-release.keystore \
    //       -PMAYA_STORE_PASSWORD=*** -PMAYA_KEY_ALIAS=maya -PMAYA_KEY_PASSWORD=***
    signingConfigs {
        create("release") {
            val storePath = project.findProperty("MAYA_STORE_FILE") as String?
            if (storePath != null) {
                storeFile = file(storePath)
                storePassword = project.findProperty("MAYA_STORE_PASSWORD") as String?
                keyAlias = project.findProperty("MAYA_KEY_ALIAS") as String?
                keyPassword = project.findProperty("MAYA_KEY_PASSWORD") as String?
            }
        }
    }

    buildTypes {
        release {
            isMinifyEnabled = false
            signingConfig = if (project.hasProperty("MAYA_STORE_FILE")) {
                signingConfigs.getByName("release")
            } else {
                signingConfigs.getByName("debug")
            }
            proguardFiles(
                getDefaultProguardFile("proguard-android-optimize.txt"),
                "proguard-rules.pro"
            )
        }
    }

    compileOptions {
        sourceCompatibility = JavaVersion.VERSION_17
        targetCompatibility = JavaVersion.VERSION_17
    }

    kotlinOptions {
        jvmTarget = "17"
    }

    buildFeatures {
        viewBinding = true
    }
}

dependencies {
    implementation("androidx.core:core-ktx:1.13.1")
    implementation("androidx.appcompat:appcompat:1.7.0")
    implementation("com.google.android.material:material:1.12.0")
    implementation("androidx.constraintlayout:constraintlayout:2.1.4")
    implementation("androidx.fragment:fragment-ktx:1.8.2")
    implementation("androidx.recyclerview:recyclerview:1.3.2")
}
