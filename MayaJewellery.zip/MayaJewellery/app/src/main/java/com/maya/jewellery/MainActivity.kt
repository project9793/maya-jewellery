package com.maya.jewellery

import android.graphics.Color
import android.os.Bundle
import android.view.LayoutInflater
import android.view.View
import android.widget.AdapterView
import android.widget.ArrayAdapter
import androidx.appcompat.app.AppCompatActivity
import androidx.core.widget.doAfterTextChanged
import com.maya.jewellery.databinding.ActivityMainBinding
import com.maya.jewellery.databinding.ItemCaratBinding
import java.text.NumberFormat
import java.util.Locale
import kotlin.math.abs

data class Karat(val name: String, val purity: Int, val color: String)

class MainActivity : AppCompatActivity() {

    private lateinit var b: ActivityMainBinding
    private var isBuy = true

    private val karats = listOf(
        Karat("24 कैरेट", 999, "#D4AF37"),
        Karat("22 कैरेट", 916, "#E0A030"),
        Karat("21 कैरेट", 875, "#C98A2B"),
        Karat("20 कैरेट", 833, "#B87333"),
        Karat("18 कैरेट", 750, "#A0522D"),
        Karat("14 कैरेट", 585, "#8B4513"),
        Karat("9 कैरेट", 375, "#6D4C41")
    )

    private val nf: NumberFormat = NumberFormat.getNumberInstance(Locale("en", "IN")).apply {
        maximumFractionDigits = 2
        minimumFractionDigits = 0
    }

    private fun money(v: Double) = "₹" + nf.format(v)

    private fun perGram(rate10g: Double, purity: Int): Double =
        rate10g / 10.0 / 999.0 * purity

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        b = ActivityMainBinding.inflate(layoutInflater)
        setContentView(b.root)

        val prefs = getSharedPreferences("maya", MODE_PRIVATE)
        b.etRate.setText(prefs.getString("rate", "150000"))

        b.spCarat.adapter = ArrayAdapter(
            this, android.R.layout.simple_spinner_dropdown_item,
            karats.map { "${it.name} (${it.purity})" }
        )
        b.spCarat.setSelection(1)
        b.spCarat.onItemSelectedListener = object : AdapterView.OnItemSelectedListener {
            override fun onItemSelected(p: AdapterView<*>?, v: View?, pos: Int, id: Long) = refresh()
            override fun onNothingSelected(p: AdapterView<*>?) {}
        }

        b.toggleMode.addOnButtonCheckedListener { _, checkedId, checked ->
            if (checked) {
                isBuy = checkedId == b.btnBuy.id
                b.tilMaking.visibility = if (isBuy) View.VISIBLE else View.GONE
                b.tilGst.visibility = if (isBuy) View.VISIBLE else View.GONE
                b.tilDeduct.visibility = if (isBuy) View.GONE else View.VISIBLE
                refresh()
            }
        }

        b.etRate.doAfterTextChanged {
            prefs.edit().putString("rate", it?.toString() ?: "").apply()
            refresh()
        }
        listOf(b.etWeight, b.etMaking, b.etGst, b.etDeduct, b.etQuoted).forEach {
            it.doAfterTextChanged { refresh() }
        }
        refresh()
    }

    private fun num(s: CharSequence?) = s?.toString()?.toDoubleOrNull() ?: 0.0

    private fun refresh() {
        val rate10 = num(b.etRate.text)
        val weight = num(b.etWeight.text)
        val making = num(b.etMaking.text)
        val gst = num(b.etGst.text)
        val deduct = num(b.etDeduct.text)

        b.tvFormula.text = "फ़ॉर्मूला: (₹${nf.format(rate10)} ÷ 10 ÷ 999) × कैरेट प्योरिटी = 1 ग्राम का रेट"

        b.llCards.removeAllViews()
        for (k in karats) {
            val c = ItemCaratBinding.inflate(LayoutInflater.from(this), b.llCards, false)
            val pg = perGram(rate10, k.purity)
            c.viewStrip.setBackgroundColor(Color.parseColor(k.color))
            c.tvTitle.text = "${k.name} (${k.purity})"
            c.tvPerGram.text = money(pg)

            if (weight <= 0.0) {
                c.tvDetails.text = "वज़न डालें तो कुल कीमत दिखेगी"
                c.boxTotal.visibility = View.GONE
            } else {
                val metal = pg * weight
                if (isBuy) {
                    val mk = metal * making / 100.0
                    val tax = (metal + mk) * gst / 100.0
                    c.tvDetails.text = "सोने की कीमत (${nf.format(weight)} g): ${money(metal)}\n" +
                        "मेकिंग (${nf.format(making)}%): ${money(mk)}\n" +
                        "GST (${nf.format(gst)}%): ${money(tax)}"
                    c.tvTotalLabel.text = "कुल देना होगा"
                    c.tvTotal.text = money(metal + mk + tax)
                } else {
                    val cut = metal * deduct / 100.0
                    c.tvDetails.text = "सोने की कीमत (${nf.format(weight)} g): ${money(metal)}\n" +
                        "कटौती (${nf.format(deduct)}%): −${money(cut)}"
                    c.tvTotalLabel.text = "आपको मिलना चाहिए"
                    c.tvTotal.text = money(metal - cut)
                }
                c.boxTotal.visibility = View.VISIBLE
            }
            b.llCards.addView(c.root)
        }

        val k = karats[b.spCarat.selectedItemPosition.coerceAtLeast(0)]
        val fair = perGram(rate10, k.purity)
        val quoted = num(b.etQuoted.text)
        if (quoted <= 0.0 || fair <= 0.0) {
            b.tvCheck.setTextColor(Color.GRAY)
            b.tvCheck.text = "सही रेट (${k.name}): ${money(fair)} प्रति ग्राम"
        } else {
            val diff = quoted - fair
            val pct = diff / fair * 100.0
            if (abs(pct) < 0.5) {
                b.tvCheck.setTextColor(Color.parseColor("#1B7F3B"))
                b.tvCheck.text = "✅ रेट सही है (${money(fair)}/g)"
            } else if (diff > 0) {
                b.tvCheck.setTextColor(Color.parseColor("#C62828"))
                b.tvCheck.text = "⚠️ ज्वेलर ${money(diff)}/g (${nf.format(pct)}%) ज्यादा ले रहा है।\nसही रेट: ${money(fair)}/g"
            } else {
                b.tvCheck.setTextColor(Color.parseColor("#1B7F3B"))
                b.tvCheck.text = "✅ ज्वेलर का रेट ${money(-diff)}/g कम है।\nसही रेट: ${money(fair)}/g"
            }
        }
    }
}
