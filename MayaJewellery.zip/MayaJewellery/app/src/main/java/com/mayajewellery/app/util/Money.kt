package com.mayajewellery.app.util

import java.text.NumberFormat
import java.util.Locale
import kotlin.math.roundToLong

/** भारतीय तरीके से रकम दिखाना: ₹1,20,000 */
object Money {

    private fun formatter(decimals: Boolean): NumberFormat =
        NumberFormat.getNumberInstance(Locale("en", "IN")).apply {
            maximumFractionDigits = if (decimals) 2 else 0
            minimumFractionDigits = 0
        }

    fun rupees(value: Double): String = "₹" + formatter(false).format(safe(value).roundToLong())

    fun rupeesDecimal(value: Double): String = "₹" + formatter(true).format(safe(value))

    fun plain(value: Double): String = formatter(false).format(safe(value).roundToLong())

    fun plainDecimal(value: Double): String {
        val f = formatter(true)
        return f.format(safe(value))
    }

    fun signedRupees(value: Double): String {
        val prefix = if (value > 0) "+" else if (value < 0) "-" else ""
        return prefix + rupees(kotlin.math.abs(value))
    }

    fun percent(value: Double): String = String.format(Locale.US, "%.1f", safe(value)) + "%"

    /** टेक्स्ट बॉक्स से संख्या, खाली या गलत होने पर 0. */
    fun parse(text: CharSequence?): Double {
        val cleaned = text?.toString()?.replace(",", "")?.replace(" ", "")?.trim().orEmpty()
        return cleaned.toDoubleOrNull() ?: 0.0
    }

    private fun safe(value: Double): Double = if (value.isFinite()) value else 0.0
}
