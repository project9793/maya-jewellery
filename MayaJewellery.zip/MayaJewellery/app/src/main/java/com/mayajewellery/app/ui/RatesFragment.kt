package com.mayajewellery.app.ui

import android.os.Bundle
import android.view.LayoutInflater
import android.view.View
import android.view.ViewGroup
import android.view.inputmethod.InputMethodManager
import android.widget.Toast
import androidx.core.content.ContextCompat
import androidx.fragment.app.Fragment
import androidx.recyclerview.widget.GridLayoutManager
import androidx.recyclerview.widget.LinearLayoutManager
import com.mayajewellery.app.MainActivity
import com.mayajewellery.app.R
import com.mayajewellery.app.data.RateRepository
import com.mayajewellery.app.databinding.FragmentRatesBinding
import com.mayajewellery.app.util.Money
import java.text.SimpleDateFormat
import java.util.Date
import java.util.Locale

class RatesFragment : Fragment(R.layout.fragment_rates) {

    private var _binding: FragmentRatesBinding? = null
    private val binding get() = _binding!!

    private lateinit var repository: RateRepository
    private lateinit var caratAdapter: CaratAdapter
    private lateinit var historyAdapter: HistoryAdapter

    override fun onCreateView(
        inflater: LayoutInflater,
        container: ViewGroup?,
        savedInstanceState: Bundle?
    ): View {
        _binding = FragmentRatesBinding.inflate(inflater, container, false)
        return binding.root
    }

    override fun onViewCreated(view: View, savedInstanceState: Bundle?) {
        repository = RateRepository(requireContext())

        caratAdapter = CaratAdapter { carat ->
            (activity as? MainActivity)?.openCalculator(carat)
        }
        binding.rvCarats.layoutManager = GridLayoutManager(requireContext(), 2)
        binding.rvCarats.adapter = caratAdapter
        binding.rvCarats.isNestedScrollingEnabled = false

        historyAdapter = HistoryAdapter()
        binding.rvHistory.layoutManager = LinearLayoutManager(requireContext())
        binding.rvHistory.adapter = historyAdapter
        binding.rvHistory.isNestedScrollingEnabled = false

        val saved = repository.basePer10g()
        if (saved > 0.0) {
            binding.etRate.setText(Money.plainDecimal(saved))
            binding.etRate.setSelection(binding.etRate.text?.length ?: 0)
        }

        binding.btnSaveRate.setOnClickListener { saveRate() }
        refresh()
    }

    override fun onResume() {
        super.onResume()
        if (_binding != null) refresh()
    }

    private fun saveRate() {
        val value = Money.parse(binding.etRate.text)
        if (value <= 0.0) {
            Toast.makeText(requireContext(), R.string.rate_invalid, Toast.LENGTH_SHORT).show()
            return
        }
        repository.saveBasePer10g(value)
        hideKeyboard()
        Toast.makeText(requireContext(), R.string.rate_saved_toast, Toast.LENGTH_SHORT).show()
        refresh()
    }

    private fun refresh() {
        val basePerGram = repository.basePerGram()
        val hasRate = basePerGram > 0.0

        if (hasRate) {
            binding.tvPerGramInfo.text = Money.rupees(basePerGram) + " " +
                getString(R.string.per_gram) + "  •  " +
                Money.rupees(basePerGram * TOLA_IN_GRAMS) + " " + getString(R.string.per_tola)
            binding.tvLastUpdated.text = getString(R.string.last_updated_prefix) +
                formatTime(repository.lastUpdated())
            binding.tvLastUpdated.visibility = View.VISIBLE
            binding.tvRateWarning.visibility = View.GONE
        } else {
            binding.tvPerGramInfo.text = ""
            binding.tvLastUpdated.visibility = View.GONE
            binding.tvRateWarning.visibility = View.VISIBLE
        }

        caratAdapter.updateBase(basePerGram)

        val history = repository.history()
        historyAdapter.submit(history)
        binding.tvHistoryEmpty.visibility = if (history.isEmpty()) View.VISIBLE else View.GONE
    }

    private fun formatTime(millis: Long): String {
        if (millis <= 0L) return "—"
        val format = SimpleDateFormat("dd MMM yyyy, HH:mm", Locale("en", "IN"))
        return format.format(Date(millis))
    }

    private fun hideKeyboard() {
        val imm = ContextCompat.getSystemService(requireContext(), InputMethodManager::class.java)
        imm?.hideSoftInputFromWindow(binding.root.windowToken, 0)
        binding.etRate.clearFocus()
    }

    override fun onDestroyView() {
        super.onDestroyView()
        binding.rvCarats.adapter = null
        binding.rvHistory.adapter = null
        _binding = null
    }

    private companion object {
        const val TOLA_IN_GRAMS = 11.664
    }
}
