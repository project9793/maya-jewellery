package com.mayajewellery.app.ui

import androidx.fragment.app.Fragment
import com.mayajewellery.app.R

/** पूरा कंटेंट लेआउट में स्ट्रिंग्स से आता है, इसलिए कोई कोड नहीं चाहिए। */
class GuideFragment : Fragment(R.layout.fragment_guide)
