package com.mayajewellery.app.ui

import android.view.LayoutInflater
import android.view.View
import android.view.ViewGroup
import androidx.core.content.ContextCompat
import androidx.recyclerview.widget.RecyclerView
import com.mayajewellery.app.R
import com.mayajewellery.app.data.RateEntry
import com.mayajewellery.app.databinding.ItemHistoryBinding
import com.mayajewellery.app.util.Money
import java.text.SimpleDateFormat
import java.util.Date
import java.util.Locale

class HistoryAdapter : RecyclerView.Adapter<HistoryAdapter.ViewHolder>() {

    private var items: List<RateEntry> = emptyList()
    private val dateFormat = SimpleDateFormat("dd MMM yyyy, HH:mm", Locale("en", "IN"))

    fun submit(list: List<RateEntry>) {
        items = list
        notifyDataSetChanged()
    }

    override fun onCreateViewHolder(parent: ViewGroup, viewType: Int): ViewHolder =
        ViewHolder(ItemHistoryBinding.inflate(LayoutInflater.from(parent.context), parent, false))

    override fun getItemCount(): Int = items.size

    override fun onBindViewHolder(holder: ViewHolder, position: Int) {
        val binding = holder.binding
        val context = binding.root.context
        val entry = items[position]

        binding.tvDate.text = dateFormat.format(Date(entry.timeMillis))
        binding.tvRate.text = Money.rupees(entry.per10g)

        val older = items.getOrNull(position + 1)
        if (older == null) {
            binding.tvChange.visibility = View.GONE
        } else {
            val diff = entry.per10g - older.per10g
            binding.tvChange.visibility = View.VISIBLE
            if (diff == 0.0) {
                binding.tvChange.text = "—"
                binding.tvChange.setBackgroundResource(R.drawable.bg_pill_gold)
                binding.tvChange.setTextColor(ContextCompat.getColor(context, R.color.gold_deep))
            } else {
                binding.tvChange.text = Money.signedRupees(diff)
                if (diff > 0) {
                    binding.tvChange.setBackgroundResource(R.drawable.bg_pill_green)
                    binding.tvChange.setTextColor(ContextCompat.getColor(context, R.color.green))
                } else {
                    binding.tvChange.setBackgroundResource(R.drawable.bg_pill_red)
                    binding.tvChange.setTextColor(ContextCompat.getColor(context, R.color.red))
                }
            }
        }
    }

    class ViewHolder(val binding: ItemHistoryBinding) : RecyclerView.ViewHolder(binding.root)
}
