package com.mayajewellery.app

import android.os.Bundle
import androidx.appcompat.app.AppCompatActivity
import androidx.fragment.app.Fragment
import com.mayajewellery.app.data.Carat
import com.mayajewellery.app.databinding.ActivityMainBinding
import com.mayajewellery.app.ui.CalculatorFragment
import com.mayajewellery.app.ui.GuideFragment
import com.mayajewellery.app.ui.RatesFragment
import com.mayajewellery.app.ui.SellFragment

class MainActivity : AppCompatActivity() {

    private lateinit var binding: ActivityMainBinding

    /** भाव स्क्रीन से कैरेट दबाने पर यह यहां रखा जाता है और कैलकुलेटर उठा लेता है। */
    private var pendingCarat: Carat? = null

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        binding = ActivityMainBinding.inflate(layoutInflater)
        setContentView(binding.root)

        val startTab = savedInstanceState?.getInt(KEY_TAB, R.id.nav_rates) ?: R.id.nav_rates
        binding.bottomNav.selectedItemId = startTab
        if (savedInstanceState == null) {
            fragmentFor(startTab)?.let { show(it) }
        }

        binding.bottomNav.setOnItemSelectedListener { item ->
            val fragment = fragmentFor(item.itemId)
            if (fragment != null) {
                show(fragment)
                true
            } else {
                false
            }
        }
        binding.bottomNav.setOnItemReselectedListener { /* कुछ न करें */ }
    }

    private fun fragmentFor(itemId: Int): Fragment? = when (itemId) {
        R.id.nav_rates -> RatesFragment()
        R.id.nav_calc -> CalculatorFragment()
        R.id.nav_sell -> SellFragment()
        R.id.nav_guide -> GuideFragment()
        else -> null
    }

    private fun show(fragment: Fragment) {
        supportFragmentManager.beginTransaction()
            .replace(R.id.fragment_container, fragment)
            .commit()
    }

    fun openCalculator(carat: Carat) {
        pendingCarat = carat
        if (binding.bottomNav.selectedItemId == R.id.nav_calc) {
            show(CalculatorFragment())
        } else {
            binding.bottomNav.selectedItemId = R.id.nav_calc
        }
    }

    fun consumePendingCarat(): Carat? {
        val carat = pendingCarat
        pendingCarat = null
        return carat
    }

    override fun onSaveInstanceState(outState: Bundle) {
        outState.putInt(KEY_TAB, binding.bottomNav.selectedItemId)
        super.onSaveInstanceState(outState)
    }

    private companion object {
        const val KEY_TAB = "selected_tab"
    }
}
