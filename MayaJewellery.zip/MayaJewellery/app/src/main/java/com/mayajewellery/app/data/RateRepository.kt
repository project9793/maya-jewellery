package com.mayajewellery.app.data

import android.content.Context
import org.json.JSONArray
import org.json.JSONObject

data class RateEntry(val timeMillis: Long, val per10g: Double)

/**
 * भाव और भाव का इतिहास फोन में ही सेव रहता है। ऐप को इंटरनेट की जरूरत नहीं।
 */
class RateRepository(context: Context) {

    private val prefs = context.applicationContext
        .getSharedPreferences(PREFS, Context.MODE_PRIVATE)

    /** 999 फाइननेस का भाव प्रति ग्राम, नहीं डाला हो तो 0. */
    fun basePerGram(): Double =
        prefs.getString(KEY_BASE_PER_GRAM, null)?.toDoubleOrNull() ?: 0.0

    fun basePer10g(): Double = basePerGram() * 10.0

    fun hasRate(): Boolean = basePerGram() > 0.0

    fun lastUpdated(): Long = prefs.getLong(KEY_UPDATED_AT, 0L)

    fun saveBasePer10g(per10g: Double) {
        if (per10g <= 0.0) return
        prefs.edit()
            .putString(KEY_BASE_PER_GRAM, (per10g / 10.0).toString())
            .putLong(KEY_UPDATED_AT, System.currentTimeMillis())
            .apply()
        appendHistory(per10g)
    }

    fun history(): List<RateEntry> {
        val raw = prefs.getString(KEY_HISTORY, null) ?: return emptyList()
        return try {
            val array = JSONArray(raw)
            val list = ArrayList<RateEntry>(array.length())
            for (i in 0 until array.length()) {
                val obj = array.getJSONObject(i)
                list.add(RateEntry(obj.optLong("t"), obj.optDouble("r", 0.0)))
            }
            list
        } catch (e: Exception) {
            emptyList()
        }
    }

    private fun appendHistory(per10g: Double) {
        val list = history().toMutableList()
        if (list.isNotEmpty() && list[0].per10g == per10g) return
        list.add(0, RateEntry(System.currentTimeMillis(), per10g))
        while (list.size > MAX_HISTORY) {
            list.removeAt(list.size - 1)
        }
        val array = JSONArray()
        list.forEach {
            array.put(JSONObject().put("t", it.timeMillis).put("r", it.per10g))
        }
        prefs.edit().putString(KEY_HISTORY, array.toString()).apply()
    }

    private companion object {
        const val PREFS = "maya_jewellery_rates"
        const val KEY_BASE_PER_GRAM = "base_per_gram"
        const val KEY_UPDATED_AT = "updated_at"
        const val KEY_HISTORY = "rate_history"
        const val MAX_HISTORY = 20
    }
}
