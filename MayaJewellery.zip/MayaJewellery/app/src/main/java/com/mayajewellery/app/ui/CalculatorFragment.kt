package com.mayajewellery.app.ui

import android.content.Intent
import android.os.Bundle
import android.text.Editable
import android.text.TextWatcher
import android.view.LayoutInflater
import android.view.View
import android.view.ViewGroup
import android.widget.ArrayAdapter
import androidx.fragment.app.Fragment
import com.mayajewellery.app.MainActivity
import com.mayajewellery.app.R
import com.mayajewellery.app.data.Carat
import com.mayajewellery.app.data.RateRepository
import com.mayajewellery.app.databinding.FragmentCalculatorBinding
import com.mayajewellery.app.util.Money
import java.text.SimpleDateFormat
import java.util.Date
import java.util.Locale

class CalculatorFragment : Fragment(R.layout.fragment_calculator) {

    private var _binding: FragmentCalculatorBinding? = null
    private val binding get() = _binding!!

    private lateinit var repository: RateRepository
    private var selectedCarat: Carat = Carat.K22
    private var makingInPercent: Boolean = true
    private var updating: Boolean = false

    override fun onCreateView(
        inflater: LayoutInflater,
        container: ViewGroup?,
        savedInstanceState: Bundle?
    ): View {
        _binding = FragmentCalculatorBinding.inflate(inflater, container, false)
        return binding.root
    }

    override fun onViewCreated(view: View, savedInstanceState: Bundle?) {
        repository = RateRepository(requireContext())

        setupCaratDropdown()

        (activity as? MainActivity)?.consumePendingCarat()?.let { carat ->
            selectedCarat = carat
            binding.acCarat.setText(carat.dropdownLabel(), false)
        }

        binding.chipsWeight.setOnCheckedStateChangeListener { _, checkedIds ->
            if (updating || checkedIds.isEmpty()) return@setOnCheckedStateChangeListener
            val grams = when (checkedIds[0]) {
                R.id.chip_1g -> "1"
                R.id.chip_5g -> "5"
                R.id.chip_10g -> "10"
                R.id.chip_tola -> "11.664"
                else -> return@setOnCheckedStateChangeListener
            }
            binding.etWeight.setText(grams)
            binding.etWeight.setSelection(binding.etWeight.text?.length ?: 0)
        }

        binding.chipsMakingMode.setOnCheckedStateChangeListener { _, checkedIds ->
            if (updating || checkedIds.isEmpty()) return@setOnCheckedStateChangeListener
            makingInPercent = checkedIds[0] == R.id.chip_mode_percent
            recalc()
        }

        listOf(
            binding.etWeight, binding.etMaking, binding.etWastage,
            binding.etStone, binding.etHallmark
        ).forEach { field ->
            field.addTextChangedListener(object : TextWatcher {
                override fun beforeTextChanged(s: CharSequence?, a: Int, b: Int, c: Int) = Unit
                override fun onTextChanged(s: CharSequence?, a: Int, b: Int, c: Int) = Unit
                override fun afterTextChanged(s: Editable?) = recalc()
            })
        }

        binding.switchMakingGst.setOnCheckedChangeListener { _, _ -> recalc() }
        binding.btnReset.setOnClickListener { resetForm() }
        binding.btnShare.setOnClickListener { shareBill() }

        recalc()
    }

    private fun setupCaratDropdown() {
        val labels = Carat.entries.map { it.dropdownLabel() }
        val adapter = ArrayAdapter(
            requireContext(),
            android.R.layout.simple_list_item_1,
            labels
        )
        binding.acCarat.setAdapter(adapter)
        binding.acCarat.setText(selectedCarat.dropdownLabel(), false)
        binding.acCarat.setOnItemClickListener { _, _, position, _ ->
            selectedCarat = Carat.entries[position]
            recalc()
        }
    }

    private fun recalc() {
        if (_binding == null) return

        val basePerGram = repository.basePerGram()
        val ratePerGram = selectedCarat.ratePerGram(basePerGram)
        binding.tvRateStrip.text = selectedCarat.dropdownLabel() + "  •  " +
            Money.rupees(ratePerGram) + " " + getString(R.string.per_gram)

        val hasRate = basePerGram > 0.0
        binding.tvCalcWarning.visibility = if (hasRate) View.GONE else View.VISIBLE

        val weight = Money.parse(binding.etWeight.text)
        val makingInput = Money.parse(binding.etMaking.text)
        val wastagePercent = Money.parse(binding.etWastage.text)
        val stone = Money.parse(binding.etStone.text)
        val hallmark = Money.parse(binding.etHallmark.text)

        val metal = ratePerGram * weight
        val making = if (makingInPercent) metal * makingInput / 100.0 else makingInput * weight
        val wastage = metal * wastagePercent / 100.0

        val subTotal = metal + making + wastage + stone + hallmark
        val gst = if (binding.switchMakingGst.isChecked) {
            (metal + wastage + stone) * GST_ON_GOLD + making * GST_ON_MAKING
        } else {
            subTotal * GST_ON_GOLD
        }
        val total = subTotal + gst
        val perGramCost = if (weight > 0.0) total / weight else 0.0
        val extra = total - metal
        val extraPercent = if (metal > 0.0) extra / metal * 100.0 else 0.0

        binding.tvMetal.text = Money.rupees(metal)
        binding.tvMaking.text = Money.rupees(making)
        binding.tvWastage.text = Money.rupees(wastage)
        binding.tvStone.text = Money.rupees(stone)
        binding.tvHallmark.text = Money.rupees(hallmark)
        binding.tvGst.text = Money.rupees(gst)
        binding.tvTotal.text = Money.rupees(total)

        binding.rowWastage.visibility = if (wastage > 0.0) View.VISIBLE else View.GONE
        binding.rowStone.visibility = if (stone > 0.0) View.VISIBLE else View.GONE
        binding.rowHallmark.visibility = if (hallmark > 0.0) View.VISIBLE else View.GONE

        binding.tvPerGramCost.text = getString(R.string.row_per_gram) + ": " + Money.rupees(perGramCost)
        binding.tvExtra.text = getString(R.string.row_extra) + ": " +
            Money.rupees(extra) + " (" + Money.percent(extraPercent) + ")"
    }

    private fun resetForm() {
        updating = true
        binding.etWeight.setText("10")
        binding.etMaking.setText("12")
        binding.etWastage.setText("0")
        binding.etStone.setText("")
        binding.etHallmark.setText("45")
        binding.switchMakingGst.isChecked = false
        binding.chipsWeight.clearCheck()
        binding.chipModePercent.isChecked = true
        makingInPercent = true
        updating = false
        recalc()
    }

    private fun shareBill() {
        val weight = Money.parse(binding.etWeight.text)
        val today = SimpleDateFormat("dd MMM yyyy", Locale("en", "IN")).format(Date())

        val text = buildString {
            appendLine(getString(R.string.app_name))
            appendLine(today + "  •  " + selectedCarat.dropdownLabel())
            appendLine(getString(R.string.label_weight) + ": " + Money.plainDecimal(weight) + " g")
            appendLine()
            appendLine(getString(R.string.row_metal) + ": " + binding.tvMetal.text)
            appendLine(getString(R.string.row_making) + ": " + binding.tvMaking.text)
            if (binding.rowWastage.visibility == View.VISIBLE) {
                appendLine(getString(R.string.row_wastage) + ": " + binding.tvWastage.text)
            }
            if (binding.rowStone.visibility == View.VISIBLE) {
                appendLine(getString(R.string.row_stone) + ": " + binding.tvStone.text)
            }
            if (binding.rowHallmark.visibility == View.VISIBLE) {
                appendLine(getString(R.string.row_hallmark) + ": " + binding.tvHallmark.text)
            }
            appendLine(getString(R.string.row_gst) + ": " + binding.tvGst.text)
            appendLine(getString(R.string.row_total) + ": " + binding.tvTotal.text)
            appendLine(binding.tvPerGramCost.text)
        }

        val intent = Intent(Intent.ACTION_SEND).apply {
            type = "text/plain"
            putExtra(Intent.EXTRA_SUBJECT, getString(R.string.app_name))
            putExtra(Intent.EXTRA_TEXT, text)
        }
        startActivity(Intent.createChooser(intent, getString(R.string.share_chooser)))
    }

    override fun onDestroyView() {
        super.onDestroyView()
        _binding = null
    }

    private companion object {
        const val GST_ON_GOLD = 0.03
        const val GST_ON_MAKING = 0.05
    }
}
