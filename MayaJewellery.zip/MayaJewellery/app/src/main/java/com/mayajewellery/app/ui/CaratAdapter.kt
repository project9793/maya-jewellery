package com.mayajewellery.app.ui

import android.view.LayoutInflater
import android.view.ViewGroup
import androidx.recyclerview.widget.RecyclerView
import com.mayajewellery.app.R
import com.mayajewellery.app.data.Carat
import com.mayajewellery.app.databinding.ItemCaratBinding
import com.mayajewellery.app.util.Money

class CaratAdapter(private val onClick: (Carat) -> Unit) :
    RecyclerView.Adapter<CaratAdapter.ViewHolder>() {

    private val items: List<Carat> = Carat.entries.toList()
    private var basePerGram: Double = 0.0

    fun updateBase(base: Double) {
        basePerGram = base
        notifyDataSetChanged()
    }

    override fun onCreateViewHolder(parent: ViewGroup, viewType: Int): ViewHolder =
        ViewHolder(ItemCaratBinding.inflate(LayoutInflater.from(parent.context), parent, false))

    override fun getItemCount(): Int = items.size

    override fun onBindViewHolder(holder: ViewHolder, position: Int) {
        val carat = items[position]
        val binding = holder.binding
        val context = binding.root.context

        binding.tvCarat.text = carat.shortName
        binding.tvFineness.text = carat.fineness.toString() + " • " + carat.purityPercent() + "%"

        if (basePerGram > 0.0) {
            val rate = carat.ratePerGram(basePerGram)
            binding.tvPerGram.text = Money.rupees(rate)
            binding.tvPer10g.text =
                Money.rupees(rate * 10.0) + " " + context.getString(R.string.per_10g)
        } else {
            binding.tvPerGram.text = context.getString(R.string.carat_rate_empty)
            binding.tvPer10g.text = ""
        }

        binding.root.setOnClickListener { onClick(carat) }
    }

    class ViewHolder(val binding: ItemCaratBinding) : RecyclerView.ViewHolder(binding.root)
}
