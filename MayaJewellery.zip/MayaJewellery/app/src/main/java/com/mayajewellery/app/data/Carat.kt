package com.mayajewellery.app.data

import java.util.Locale

/**
 * सोने के सभी कैरेट और उनकी फाइननेस (1000 में से शुद्ध सोना)।
 * भाव हमेशा 999 फाइननेस के भाव से निकाला जाता है, जैसे:
 * (150000 / 999 x 750) = 18 कैरेट का भाव।
 */
enum class Carat(val karat: Int, val fineness: Int) {

    K24(24, 999),
    K23(23, 958),
    K22(22, 916),
    K20(20, 833),
    K18(18, 750),
    K14(14, 585),
    K9(9, 375);

    val shortName: String
        get() = karat.toString() + "K"

    fun purityPercent(): String = String.format(Locale.US, "%.1f", fineness / 10.0)

    fun dropdownLabel(): String = shortName + " (" + fineness + ")"

    /** इस कैरेट का भाव प्रति ग्राम, 999 के भाव से निकाला हुआ। */
    fun ratePerGram(base999PerGram: Double): Double = base999PerGram / 999.0 * fineness

    companion object {
        fun ofKarat(karat: Int): Carat = entries.firstOrNull { it.karat == karat } ?: K22
    }
}
