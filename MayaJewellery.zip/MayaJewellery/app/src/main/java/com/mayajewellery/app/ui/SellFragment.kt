package com.mayajewellery.app.ui

import android.os.Bundle
import android.text.Editable
import android.text.TextWatcher
import android.view.LayoutInflater
import android.view.View
import android.view.ViewGroup
import android.widget.ArrayAdapter
import androidx.core.content.ContextCompat
import androidx.fragment.app.Fragment
import com.mayajewellery.app.R
import com.mayajewellery.app.data.Carat
import com.mayajewellery.app.data.RateRepository
import com.mayajewellery.app.databinding.FragmentSellBinding
import com.mayajewellery.app.util.Money

class SellFragment : Fragment(R.layout.fragment_sell) {

    private var _binding: FragmentSellBinding? = null
    private val binding get() = _binding!!

    private lateinit var repository: RateRepository
    private var selectedCarat: Carat = Carat.K22

    override fun onCreateView(
        inflater: LayoutInflater,
        container: ViewGroup?,
        savedInstanceState: Bundle?
    ): View {
        _binding = FragmentSellBinding.inflate(inflater, container, false)
        return binding.root
    }

    override fun onViewCreated(view: View, savedInstanceState: Bundle?) {
        repository = RateRepository(requireContext())

        val labels = Carat.entries.map { it.dropdownLabel() }
        binding.acCarat.setAdapter(
            ArrayAdapter(requireContext(), android.R.layout.simple_list_item_1, labels)
        )
        binding.acCarat.setText(selectedCarat.dropdownLabel(), false)
        binding.acCarat.setOnItemClickListener { _, _, position, _ ->
            selectedCarat = Carat.entries[position]
            recalc()
        }

        listOf(binding.etWeight, binding.etDeduction, binding.etOffer).forEach { field ->
            field.addTextChangedListener(object : TextWatcher {
                override fun beforeTextChanged(s: CharSequence?, a: Int, b: Int, c: Int) = Unit
                override fun onTextChanged(s: CharSequence?, a: Int, b: Int, c: Int) = Unit
                override fun afterTextChanged(s: Editable?) = recalc()
            })
        }

        recalc()
    }

    private fun recalc() {
        if (_binding == null) return

        val basePerGram = repository.basePerGram()
        val ratePerGram = selectedCarat.ratePerGram(basePerGram)
        val weight = Money.parse(binding.etWeight.text)
        val deduction = Money.parse(binding.etDeduction.text).coerceIn(0.0, 50.0)
        val offer = Money.parse(binding.etOffer.text)

        val metal = ratePerGram * weight
        val expected = metal * (1.0 - deduction / 100.0)
        val difference = offer - expected

        binding.tvMetal.text = Money.rupees(metal)
        binding.tvExpected.text = Money.rupees(expected)
        binding.tvOffer.text = if (offer > 0.0) Money.rupees(offer) else "—"
        binding.tvDiff.text = if (offer > 0.0) Money.signedRupees(difference) else "—"

        val context = requireContext()
        when {
            basePerGram <= 0.0 || weight <= 0.0 -> {
                binding.tvVerdict.text = getString(R.string.calc_need_rate)
                binding.tvVerdict.setBackgroundResource(R.drawable.bg_pill_gold)
                binding.tvVerdict.setTextColor(ContextCompat.getColor(context, R.color.gold_deep))
            }
            offer <= 0.0 -> {
                binding.tvVerdict.text = getString(R.string.sell_need_input)
                binding.tvVerdict.setBackgroundResource(R.drawable.bg_pill_gold)
                binding.tvVerdict.setTextColor(ContextCompat.getColor(context, R.color.gold_deep))
            }
            difference >= -1.0 -> {
                binding.tvVerdict.text = getString(R.string.sell_good) + "  ✓"
                binding.tvVerdict.setBackgroundResource(R.drawable.bg_pill_green)
                binding.tvVerdict.setTextColor(ContextCompat.getColor(context, R.color.green))
            }
            else -> {
                binding.tvVerdict.text = getString(R.string.sell_low) + "  •  " +
                    Money.rupees(-difference)
                binding.tvVerdict.setBackgroundResource(R.drawable.bg_pill_red)
                binding.tvVerdict.setTextColor(ContextCompat.getColor(context, R.color.red))
            }
        }
    }

    override fun onDestroyView() {
        super.onDestroyView()
        _binding = null
    }
}
